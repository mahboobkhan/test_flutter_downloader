import 'package:flutter/material.dart';

class VideoInfoList extends StatelessWidget {
  final Map<String, dynamic> videoData;
  final Function(String url, String title) onDownload;

  const VideoInfoList({Key? key, required this.videoData, required this.onDownload}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String title = videoData['title'] ?? 'Unknown Title';
    var formats = videoData['formats'];

    if (formats == null || !List.from(formats).isNotEmpty) {
      return const Center(child: Text('No formats available for download.'));
    }

    return ListView.builder(
      itemCount: formats.length,
      itemBuilder: (context, index) {
        final format = formats[index];

        return ListTile(
          title: Text(format['format'] ?? 'Unknown format'),
          subtitle: Text(format['resolution'] ?? 'No resolution available'),
          trailing: ElevatedButton(
            onPressed: () {
              // Call the onDownload callback
              onDownload(format['url'], title);
            },
            child: const Text('Download'),
          ),
        );
      },
    );
  }
}
