import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'VideoInfoList.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'dart:io';

import 'app/utils/Utils.dart';

class videoDownloaderScreen extends StatefulWidget {
  const videoDownloaderScreen({super.key});

  @override
  _videoDownloaderScreenState createState() => _videoDownloaderScreenState();
}

class _videoDownloaderScreenState extends State<videoDownloaderScreen> {
  final TextEditingController urlController = TextEditingController();
  Map<String, dynamic>? videoData; // Holds the video data fetched from the API
  bool isLoading = false; // Track API loading status
  List<FileSystemEntity> files = [];


  @override
  void initState() {
    super.initState();
    _checkPermissionsAndListFiles();
  }

  Future<void> _checkPermissionsAndListFiles() async {
    // Request storage permissions
    var status = await Permission.videos.request();
    if (status.isGranted) {
      // List files in the directory
      _listFiles();
    } else {
      // Handle permission denied
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Storage permission is required to access files')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: urlController,
              decoration: const InputDecoration(
                labelText: 'Enter Video URL',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              setState(() {
                isLoading = true; // Start loading
              });

              try {
                final data = await fetchVideoInfo(urlController.text);
                setState(() {
                  videoData = data; // Store video info in the state
                });
              } catch (e) {
                // Handle error (e.g., show a snack bar)
                print("Error fetching video data: $e");
              } finally {
                setState(() {
                  isLoading = false; // End loading
                });
              }
            },
            child: const Text('Fetch Video Info'),
          ),
          Expanded(
            child: isLoading
                ? const Center(
                    child: CircularProgressIndicator(),
                  ) // Show a loading spinner
                : videoData != null
                    ? VideoInfoList(
                        videoData: videoData!,
                        onDownload: (url, title) {
                          _downloadFile(url, title);
                        },
                      ) // Show video info if available.
                    : const Center(
                        child: Text('No video data available'),
                      ), // Default message
          ),
        ],
      ),
    );
  }

  Future<Map<String, dynamic>> fetchVideoInfo(String url) async {
    print("status code calling");

    final response = await http.post(
      Uri.parse('http://192.168.10.11:5000/download'),//http://192.168.10.11:5000
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"url": url}),
    );

    if (response.statusCode == 200) {
      print("status code 200");

      return jsonDecode(response.body);
    } else {
      print("status code exceptions");

      throw Exception('Failed to load video info');
    }
  }



  void _listFiles() {
    Directory directory = Directory(directoryPath);
    setState(() {
      files = directory.listSync(); // List all files
    });
  }
}
