import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'DownloadDonfragment.dart';
import 'DownloadProgressFragment.dart';
import 'VideoDownloaderScreen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3, // Number of tabs
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Video Downloader'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Download'),
              Tab(text: 'Watch'),
              Tab(text: 'Progress'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            videoDownloaderScreen(), // First Tab
            DownloadDoneFregment(), // Second Tab
            DownloadProgressFragment(), // Third Tab
          ],
        ),
      ),
    );
  }
}
