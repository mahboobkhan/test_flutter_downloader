import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

class DownloadProvider with ChangeNotifier {
  bool isDownloading = false;
  bool isPaused = false;
  String progress = '0%';
  CancelToken? cancelToken; // Used to pause or cancel download
  Dio dio = Dio(); // Dio instance

  // Start the download
  Future<void> downloadFile(String url, String title) async {
    try {
      // Set the downloading state
      isDownloading = true;
      isPaused = false;
      progress = '0%';
      notifyListeners();

      // Get the app's directory to save the file
      Directory? appDocDir = await getExternalStorageDirectory();
      String savePath = '${appDocDir?.path}/$title.mp4'; // Adjust extension if needed

      // Initialize CancelToken to control the request
      cancelToken = CancelToken();

      // Download the file using Dio
      await dio.download(
        url,
        savePath,
        onReceiveProgress: (received, total) {
          if (total != -1) {
            // Update progress
            progress = "${(received / total * 100).toStringAsFixed(0)}%";
            notifyListeners();
          }
        },
        cancelToken: cancelToken,
        options: Options(
          headers: {
            'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
          },
        ),
      );
      isDownloading = false;
      progress = "Download complete";
      notifyListeners();
    } catch (exception) {
      if (CancelToken.isCancel(exception)) {
        progress = "Download paused";
      } else {
        progress = "Error downloading file: $exception";
      }
      isDownloading = false;
      notifyListeners();
    }
  }

  // Pause the download
  void pauseDownload() {
    if (isDownloading && !isPaused && cancelToken != null) {
      cancelToken!.cancel("Download paused");
      isPaused = true;
      notifyListeners();
    }
  }

  // Resume the download
  Future<void> resumeDownload(String url, String title) async {
    if (isPaused) {
      isPaused = false;
      downloadFile(url, title); // Re-initiate the download
    }
  }

  // Cancel the download completely
  void cancelDownload() {
    if (isDownloading && cancelToken != null) {
      cancelToken!.cancel("Download canceled");
      isDownloading = false;
      notifyListeners();
    }
  }
}
