import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DownloadProgressFragment extends StatefulWidget {
  @override
  _DownloadProgressFragmentState createState() => _DownloadProgressFragmentState();
}

class _DownloadProgressFragmentState extends State<DownloadProgressFragment> {
  int progress = 0;

  void updateProgress(int newProgress) {
    setState(() {
      progress = newProgress;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Download Progress: $progress%'),
          LinearProgressIndicator(value: progress / 100),
        ],
      ),
    );
  }
}
